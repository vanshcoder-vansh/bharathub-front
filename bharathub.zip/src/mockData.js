// Mock data for BharatHub e-commerce clone

export const categories = [
  {
    id: 1,
    name: "Electronics",
    productCount: 245,
    image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=500&h=400&fit=crop",
    link: "/categories/electronics"
  },
  {
    id: 2,
    name: "Fashion",
    productCount: 532,
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=500&h=400&fit=crop",
    link: "/categories/fashion"
  },
  {
    id: 3,
    name: "Home & Kitchen",
    productCount: 189,
    image: "https://images.unsplash.com/photo-1556911220-bff31c812dba?w=500&h=400&fit=crop",
    link: "/categories/home-kitchen"
  },
  {
    id: 4,
    name: "Beauty & Personal Care",
    productCount: 312,
    image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500&h=400&fit=crop",
    link: "/categories/beauty"
  },
  {
    id: 5,
    name: "Sports & Fitness",
    productCount: 156,
    image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500&h=400&fit=crop",
    link: "/categories/sports"
  },
  {
    id: 6,
    name: "Books & Stationery",
    productCount: 423,
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500&h=400&fit=crop",
    link: "/categories/books"
  }
];

export const trendingProducts = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=300&h=300&fit=crop",
    rating: 4.5,
    reviewCount: 1234,
    originalPrice: 2499,
    discountedPrice: 1299,
    discount: 48,
    cod: true,
    link: "/product/1"
  },
  {
    id: 2,
    name: "Cotton Casual T-Shirt",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    rating: 4.3,
    reviewCount: 856,
    originalPrice: 999,
    discountedPrice: 499,
    discount: 50,
    cod: true,
    link: "/product/2"
  },
  {
    id: 3,
    name: "Stainless Steel Water Bottle",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=300&h=300&fit=crop",
    rating: 4.7,
    reviewCount: 2341,
    originalPrice: 699,
    discountedPrice: 349,
    discount: 50,
    cod: true,
    link: "/product/3"
  },
  {
    id: 4,
    name: "LED Desk Lamp",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=300&h=300&fit=crop",
    rating: 4.4,
    reviewCount: 567,
    originalPrice: 1599,
    discountedPrice: 799,
    discount: 50,
    cod: true,
    link: "/product/4"
  },
  {
    id: 5,
    name: "Yoga Mat with Carry Bag",
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=300&h=300&fit=crop",
    rating: 4.6,
    reviewCount: 1089,
    originalPrice: 1299,
    discountedPrice: 599,
    discount: 54,
    cod: true,
    link: "/product/5"
  },
  {
    id: 6,
    name: "Notebook Set with Pens",
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=300&h=300&fit=crop",
    rating: 4.2,
    reviewCount: 734,
    originalPrice: 499,
    discountedPrice: 249,
    discount: 50,
    cod: true,
    link: "/product/6"
  }
];

export const bestSellingProducts = [
  {
    id: 7,
    name: "Smart Fitness Band",
    image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=300&h=300&fit=crop",
    rating: 4.6,
    reviewCount: 3456,
    originalPrice: 3999,
    discountedPrice: 1999,
    soldCount: "5.2k",
    bestseller: true,
    cod: true,
    link: "/product/7"
  },
  {
    id: 8,
    name: "Premium Backpack",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    rating: 4.7,
    reviewCount: 2891,
    originalPrice: 1799,
    discountedPrice: 899,
    soldCount: "4.6k",
    bestseller: true,
    cod: true,
    link: "/product/8"
  },
  {
    id: 9,
    name: "Ceramic Coffee Mug Set",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=300&h=300&fit=crop",
    rating: 4.5,
    reviewCount: 1678,
    originalPrice: 899,
    discountedPrice: 449,
    soldCount: "3.9k",
    bestseller: true,
    cod: true,
    link: "/product/9"
  },
  {
    id: 10,
    name: "Portable Phone Stand",
    image: "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?w=300&h=300&fit=crop",
    rating: 4.4,
    reviewCount: 2234,
    originalPrice: 499,
    discountedPrice: 199,
    soldCount: "6.8k",
    bestseller: true,
    cod: true,
    link: "/product/10"
  },
  {
    id: 11,
    name: "Resistance Bands Set",
    image: "https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=300&h=300&fit=crop",
    rating: 4.8,
    reviewCount: 1567,
    originalPrice: 1199,
    discountedPrice: 599,
    soldCount: "3.5k",
    bestseller: true,
    cod: true,
    link: "/product/11"
  },
  {
    id: 12,
    name: "Desk Organizer Set",
    image: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=300&h=300&fit=crop",
    rating: 4.3,
    reviewCount: 987,
    originalPrice: 699,
    discountedPrice: 349,
    soldCount: "2.3k",
    bestseller: true,
    cod: true,
    link: "/product/12"
  }
];

export const features = [
  {
    id: 1,
    title: "Cash on Delivery",
    description: "Pay when you receive your order. No advance payment required.",
    icon: "Banknote"
  },
  {
    id: 2,
    title: "100% Secure",
    description: "Your data is protected with industry-standard encryption.",
    icon: "Shield"
  },
  {
    id: 3,
    title: "India-wide Delivery",
    description: "We deliver to every corner of India with reliable shipping partners.",
    icon: "Truck"
  },
  {
    id: 4,
    title: "Easy Returns",
    description: "7-day hassle-free return policy on all products.",
    icon: "RefreshCw"
  },
  {
    id: 5,
    title: "Authentic Products",
    description: "All products are 100% genuine and quality-checked.",
    icon: "BadgeCheck"
  },
  {
    id: 6,
    title: "24/7 Support",
    description: "Our customer support team is always ready to help you.",
    icon: "Headphones"
  }
];
